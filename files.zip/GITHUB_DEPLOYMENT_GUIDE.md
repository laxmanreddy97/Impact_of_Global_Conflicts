# 📖 Complete Step-by-Step Guide: Deploy Your Gradio App to GitHub

> **Project:** Impact of Global Conflicts on Fuel Prices & Economic Indicators  
> **Goal:** Upload your Gradio app, notebook, and all project files to GitHub so anyone can clone and run it.

---

## 🗂️ PHASE 0 — Understand What You're Doing

Your GitHub repository will contain:

```
opwar-conflict-oil-ml/
│
├── app.py                ← Gradio UI (the interactive web app)
├── model.pkl             ← Trained Gradient Boosting model (serialised)
├── scaler.pkl            ← StandardScaler object (serialised)
├── notebook.ipynb        ← Your full Jupyter notebook (ML + Data Mining)
├── requirements.txt      ← Python packages needed to run the app
└── README.md             ← Professional project documentation
```

Anyone who clones this repo can:
1. `pip install -r requirements.txt`
2. `python app.py`
3. See your Gradio app running in their browser.

---

## ✅ PHASE 1 — Export the Model from Your Notebook

Before anything else, you need to save your trained model as a file.

### Step 1.1 — Add this cell to the END of your Jupyter notebook

```python
# ============================================================
# CELL EXPORT — Save Trained Model & Scaler
# ============================================================
import joblib

# Save the best model (Gradient Boosting)
joblib.dump(models['Gradient Boosting'], 'model.pkl')
joblib.dump(scaler, 'scaler.pkl')

print("✅ model.pkl saved")
print("✅ scaler.pkl saved")
print(f"   model.pkl size: {os.path.getsize('model.pkl')/1024:.1f} KB")
print(f"   scaler.pkl size: {os.path.getsize('scaler.pkl')/1024:.1f} KB")
```

### Step 1.2 — If running on Google Colab, download the files

```python
# Add this right after the export cell above (Colab only)
from google.colab import files
files.download('model.pkl')
files.download('scaler.pkl')
```

After running, two files will download to your computer:
- `model.pkl`
- `scaler.pkl`

> ⚠️ **If you skip this step**, `app.py` will automatically use a surrogate demo model. The app still works — just use real exports for accurate predictions.

---

## ✅ PHASE 2 — Set Up Your Local Project Folder

### Step 2.1 — Create the project folder on your computer

**Windows (Command Prompt):**
```cmd
mkdir C:\Users\YourName\opwar-conflict-oil-ml
cd C:\Users\YourName\opwar-conflict-oil-ml
```

**Mac/Linux (Terminal):**
```bash
mkdir ~/opwar-conflict-oil-ml
cd ~/opwar-conflict-oil-ml
```

### Step 2.2 — Copy all files into this folder

Move/copy these files into `opwar-conflict-oil-ml/`:

| File | Where to get it |
|---|---|
| `app.py` | Copy from this guide / provided file |
| `model.pkl` | Downloaded from Colab (Step 1.2) |
| `scaler.pkl` | Downloaded from Colab (Step 1.2) |
| `notebook.ipynb` | Your Jupyter notebook file |
| `requirements.txt` | Copy from this guide / provided file |
| `README.md` | Copy from this guide / provided file |

### Step 2.3 — Verify the folder looks right

**Windows:**
```cmd
dir
```

**Mac/Linux:**
```bash
ls -la
```

You should see all 6 files listed.

---

## ✅ PHASE 3 — Install Git (If Not Already Installed)

### Step 3.1 — Check if Git is installed

```bash
git --version
```

If you see something like `git version 2.43.0` — Git is already installed. Skip to Phase 4.

### Step 3.2 — Install Git if needed

- **Windows:** Download from https://git-scm.com/download/win → run installer → keep all defaults
- **Mac:** Run `xcode-select --install` in Terminal, or install via https://git-scm.com/download/mac
- **Linux (Ubuntu/Debian):** `sudo apt-get install git`

### Step 3.3 — Configure Git with your identity (one-time setup)

```bash
git config --global user.name "Your Full Name"
git config --global user.email "your@email.com"
```

---

## ✅ PHASE 4 — Create a GitHub Account & New Repository

### Step 4.1 — Create a GitHub account

1. Go to **https://github.com**
2. Click **Sign up**
3. Enter your email, password, username
4. Verify your email address

### Step 4.2 — Create a new repository

1. Click the **+** icon (top-right) → **New repository**
2. Fill in:
   - **Repository name:** `opwar-conflict-oil-ml`
   - **Description:** `Impact of Global Conflicts on Fuel Prices — ML + Gradio UI`
   - **Visibility:** Public *(so others can see and clone it)*
   - ❌ **Do NOT** tick "Add a README file" (you already have one)
   - ❌ **Do NOT** tick "Add .gitignore" (you'll add it manually)
   - ❌ **Do NOT** tick "Choose a license"
3. Click **Create repository**

You'll see a page with instructions — **keep this tab open**, you'll need the URL.

---

## ✅ PHASE 5 — Initialise Git Locally and Push to GitHub

Open Terminal (Mac/Linux) or Command Prompt / Git Bash (Windows).

### Step 5.1 — Navigate to your project folder

```bash
cd ~/opwar-conflict-oil-ml        # Mac/Linux
# OR
cd C:\Users\YourName\opwar-conflict-oil-ml   # Windows
```

### Step 5.2 — Initialise a local Git repository

```bash
git init
```

Output: `Initialized empty Git repository in .../opwar-conflict-oil-ml/.git/`

### Step 5.3 — Create a .gitignore file

This prevents junk files from being uploaded:

**Mac/Linux:**
```bash
cat > .gitignore << 'EOF'
# Python
__pycache__/
*.pyc
*.pyo
.env
venv/
.venv/
*.egg-info/
dist/
build/

# Jupyter
.ipynb_checkpoints/

# OS files
.DS_Store
Thumbs.db

# Large data files (upload to Kaggle / Google Drive instead)
*.csv
*.sqlite
*.db

# Gradio cache
gradio_cached_examples/
flagged/
EOF
```

**Windows (Command Prompt):**
Create a file called `.gitignore` using Notepad and paste the content above.

### Step 5.4 — Stage all files

```bash
git add .
```

### Step 5.5 — Verify what will be committed

```bash
git status
```

You should see these files listed in green:
```
new file:   .gitignore
new file:   README.md
new file:   app.py
new file:   model.pkl
new file:   notebook.ipynb
new file:   requirements.txt
new file:   scaler.pkl
```

> ⚠️ If `model.pkl` is larger than **100 MB**, GitHub will reject it. See "Large Files" note at the end.

### Step 5.6 — Create the first commit

```bash
git commit -m "Initial commit: Gradio UI, trained model, ML notebook, README"
```

### Step 5.7 — Connect to your GitHub repository

Copy the repository URL from GitHub (it looks like `https://github.com/YourUsername/opwar-conflict-oil-ml.git`).

```bash
git remote add origin https://github.com/YourUsername/opwar-conflict-oil-ml.git
```

### Step 5.8 — Push to GitHub

```bash
git branch -M main
git push -u origin main
```

GitHub will ask for your **username** and **password**.  
> ⚠️ **GitHub no longer accepts your account password** — you need a **Personal Access Token** instead. See Step 5.9.

### Step 5.9 — Create a Personal Access Token (PAT)

1. Go to GitHub → click your profile picture → **Settings**
2. Scroll down → **Developer settings** (bottom-left)
3. **Personal access tokens** → **Tokens (classic)**
4. **Generate new token (classic)**
5. Set:
   - Note: `opwar-project-push`
   - Expiration: 90 days
   - Scopes: ✅ `repo` (tick the top-level repo checkbox)
6. Click **Generate token**
7. **Copy the token immediately** — you won't see it again!

When Git asks for your password, **paste the token** instead of your GitHub password.

---

## ✅ PHASE 6 — Verify Your Repository on GitHub

1. Go to `https://github.com/YourUsername/opwar-conflict-oil-ml`
2. You should see all your files listed
3. The `README.md` renders automatically as a professional homepage

---

## ✅ PHASE 7 — (Optional) Deploy Gradio App to Hugging Face Spaces

GitHub only stores code. To make the app **publicly accessible in a browser** without running locally, deploy to **Hugging Face Spaces** (free).

### Step 7.1 — Create a Hugging Face account

Go to **https://huggingface.co** → Sign up (free)

### Step 7.2 — Create a new Space

1. Click your profile → **New Space**
2. Fill in:
   - **Space name:** `opwar-conflict-oil-predictor`
   - **License:** MIT
   - **SDK:** Gradio ← **this is critical**
   - **Hardware:** CPU basic (free)
3. Click **Create Space**

### Step 7.3 — Upload your files

In the Space, click **Files** tab → **Upload files**:

Upload these files:
- `app.py`
- `requirements.txt`
- `model.pkl`
- `scaler.pkl`

> Hugging Face automatically runs `app.py` using `gradio` as the entrypoint.

### Step 7.4 — Wait for the build (2–5 minutes)

The Space will show build logs. When it says **Running**, your app is live at:

```
https://huggingface.co/spaces/YourUsername/opwar-conflict-oil-predictor
```

### Step 7.5 — Add the live URL to your README

Edit `README.md` on GitHub, add at the top:

```markdown
[![Hugging Face Spaces](https://img.shields.io/badge/🤗%20Hugging%20Face-Spaces-blue)](https://huggingface.co/spaces/YourUsername/opwar-conflict-oil-predictor)

**🔗 Live Demo:** https://huggingface.co/spaces/YourUsername/opwar-conflict-oil-predictor
```

---

## ✅ PHASE 8 — Keep Your Repo Updated

Whenever you improve the notebook or app, push updates:

```bash
# From your project folder:
git add .
git commit -m "Improved: added SHAP feature importance chart to Gradio UI"
git push
```

---

## 🚨 Troubleshooting

### Problem: "model.pkl is too large (>100 MB)"

GitHub has a 100 MB file size limit. If your model is larger:

**Option A: Use Git LFS (Large File Storage)**

```bash
# Install Git LFS
git lfs install

# Track large files
git lfs track "*.pkl"
git add .gitattributes
git add model.pkl scaler.pkl
git commit -m "Add model via Git LFS"
git push
```

**Option B: Skip model.pkl from Git**

Add `*.pkl` to `.gitignore`. In `app.py`, the surrogate model will be used automatically. Add a note in README that users can generate `model.pkl` by running the notebook.

---

### Problem: "Permission denied (publickey)"

You're using SSH instead of HTTPS. Switch to HTTPS:

```bash
git remote set-url origin https://github.com/YourUsername/opwar-conflict-oil-ml.git
```

---

### Problem: "Nothing to commit" after `git add .`

Git may not see new files if they're in the wrong folder. Verify:

```bash
pwd          # Shows your current directory
ls -la       # Shows all files including hidden ones
```

---

### Problem: Gradio app crashes on Hugging Face Spaces

Check the **build logs** on the Space page. Common fixes:
1. Make sure `requirements.txt` includes `gradio>=4.0.0`
2. Make sure `app.py` ends with `demo.launch()` (no `share=True` needed on HF Spaces)
3. Ensure `model.pkl` and `scaler.pkl` are uploaded

---

## 📋 Quick Reference Cheatsheet

```bash
# ONE-TIME SETUP
git config --global user.name "Your Name"
git config --global user.email "your@email.com"

# INITIALISE & PUSH (first time)
cd ~/opwar-conflict-oil-ml
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/USERNAME/REPO.git
git branch -M main
git push -u origin main

# UPDATE (every time you make changes)
git add .
git commit -m "Describe your changes here"
git push

# CHECK STATUS
git status          # See what's changed
git log --oneline   # See commit history
```

---

## ✅ Final Checklist

Before submitting your project, verify:

- [ ] All 6 files are visible on your GitHub repository page
- [ ] README.md renders correctly with the table of contents
- [ ] `app.py` runs locally with `python app.py`
- [ ] Gradio UI opens in browser at `http://127.0.0.1:7860`
- [ ] Prediction tab produces a result when you click the button
- [ ] Scenario comparison tab generates a chart
- [ ] (Optional) Hugging Face Space is live and accessible via public URL
- [ ] README contains the live demo link

---

*Guide written for: Impact of Global Conflicts on Fuel Prices & Economic Indicators — Final Year Project*
